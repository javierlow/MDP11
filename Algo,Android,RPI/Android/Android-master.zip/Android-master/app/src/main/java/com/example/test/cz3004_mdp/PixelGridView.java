package com.example.test.cz3004_mdp;


import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;

public class PixelGridView extends View {
    private static final String TAG = "PixelGridView";

    private int numColumns, numRows;
    private int cellWidth, cellHeight;
    private int totalWidth, totalHeight;

    private Paint blackPaint = new Paint();
    private Paint whitePaint = new Paint();
    private Paint redPaint = new Paint();
    private Paint greenPaint = new Paint();
    private Paint robotPaint = new Paint();
    private Paint robotbackPaint = new Paint();
    private Paint waypointPaint = new Paint();
    private Paint goalZone = new Paint();


    private int[] arrowCoord = new int[3];
    ArrayList<Integer> arx = new ArrayList<Integer>();
    ArrayList<Integer> ary = new ArrayList<Integer>();
    ArrayList<Integer> ard = new ArrayList<Integer>();
    public boolean arrowpost= false;
    private boolean deleteBitmap = false;
    private Bitmap myImg ;

    private boolean[][] cellChecked;
    private boolean[][] startCellChecked;
    MapDecoder md = new MapDecoder();

    public PixelGridView(Context context) {
        this(context, null);
    }

    public PixelGridView(Context context, AttributeSet attrs) {
        super(context, attrs);

        blackPaint.setStyle(Paint.Style.FILL_AND_STROKE);
        whitePaint.setColor(Color.WHITE);
        blackPaint.setColor(Color.BLACK);
        redPaint.setColor(Color.RED);
        greenPaint.setColor(Color.GREEN);
        robotPaint.setColor(Color.GRAY);
        robotbackPaint.setColor(Color.DKGRAY);
        waypointPaint.setColor(Color.BLUE);
        goalZone.setColor(Color.rgb(225, 138, 7));

    }
    public void setTotalWidth(int totalWidth){
        this.totalWidth = totalWidth;
        calculateDimensions();
    }

    public int getTotalWidth(){
        return totalWidth;
    }

    public void setTotalHeight(int totalHeight){
        this.totalHeight = totalHeight;
        calculateDimensions();
    }

    public int getTotalHeight(){
        return totalHeight;
    }

    public void setNumColumns(int numColumns) {
        this.numColumns = numColumns;
        calculateDimensions();
    }

    public int getNumColumns() {
        return numColumns;
    }

    public void setNumRows(int numRows) {
        this.numRows = numRows;
        calculateDimensions();
    }

    public int getNumRows() {
        return numRows;
    }

    // Executed when size is changed
    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        calculateDimensions();
    }

    private void calculateDimensions() {
        if (numColumns < 1 || numRows < 1) {
            return;
        }

        // Set cells equally based on the given space
        cellWidth = getMeasuredWidth() / numColumns;
        cellHeight = getMeasuredHeight()/ numRows;

        // Need to find out what both arrays are for ~
        cellChecked = new boolean[numColumns][numRows];
        startCellChecked = new boolean[numColumns][numRows];

        // Invalidate() means 'redraw on screen' and results to a call of the view's onDraw() method
        invalidate();

    }


    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawColor(Color.WHITE);
        int[][] testMap = md.decodeMapDescriptor();

        if (numColumns == 0 || numRows == 0) {
            return;
        }

        int width = getMeasuredWidth();
        int height = getMeasuredHeight();
        int halfWidth = cellWidth / 2;
        Path path = new Path();

        //startCellChecked[13][2] = true;
        //start Point
        Paint paint = new Paint();
        paint.setColor(Color.BLACK);
        paint.setTextSize(35);

        /*
        //start Point -- Draw Start Point (Robot size is 3x3)
        for (int i = 0; i <= 2; i++) {
            for(int j= 0; j<=2;j++){

                // Draw Rectangle Method takes in 4 parameters and 1 paint
                // left: distance of the left side of rectangular from left side of canvas.
                // top:Distance of top side of rectangular from the top side of canvas
                // right:distance of the right side of rectangular from left side of canvas.
                // bottom: Distance of the bottom side of rectangle from top side of canvas.
                // Not sure why last parameter is goalZone instead of start
                canvas.drawRect(i * cellWidth, (19-j) * cellHeight, (i + 1) * cellWidth, (19- j + 1) * cellHeight, goalZone);

            }
        }

        //goal zone -- Draw Goal Point (Size is 3x3)
        for (int i = 12; i < 15; i++) {
            for(int j= 17; j< 20;j++){

                // Draw Rectangle Method takes in 4 parameters and 1 paint
                // left: distance of the left side of rectangular from left side of canvas.
                // top:Distance of top side of rectangular from the top side of canvas
                // right:distance of the right side of rectangular from left side of canvas.
                // bottom: Distance of the bottom side of rectangle from top side of canvas.
                Log.d(TAG, "HERE");
                canvas.drawRect(i * cellWidth, (19-j) * cellHeight, (i + 1) * cellWidth, (19- j + 1) * cellHeight, goalZone);
            }
        } */


        // Draw goal zone
        for (int i = 12; i <= 14; i++) {
            for(int j= 17; j<=19;j++){
                canvas.drawRect(i * cellWidth, (19-j) * cellHeight, (i + 1) * cellWidth, (19- j + 1) * cellHeight, goalZone);
            }
        }

        // Bottom for loop is related to decodeMapDescriptor in MapDecoder.txt
        for (int i = 0; i < numColumns; i++) {
            for (int j = 0; j < numRows; j++) {

                if (testMap[j][i] == 0 && (i < 12 && j < 17))
                {
                    // Overall background color
                    canvas.drawRect(i * cellWidth, j * cellHeight, (i + 1) * cellWidth, (j + 1) * cellHeight, whitePaint);
                }
                if (testMap[j][i] == 1) {
                    // Overall background color when obstacle is set
                    canvas.drawRect(i * cellWidth, j * cellHeight, (i + 1) * cellWidth, (j + 1) * cellHeight, greenPaint);
                }
                if (testMap[j][i] == 2)
                {
                    // Color of the obstacles set
                    canvas.drawRect(i * cellWidth, j * cellHeight, (i + 1) * cellWidth, (j + 1) * cellHeight, redPaint);
                }
                if (testMap[j][i] == 3)
                {
                    // Color of the back of robot
                    canvas.drawRect(i * cellWidth, j * cellHeight, (i + 1) * cellWidth, (j + 1) * cellHeight, robotbackPaint);
                }

                if (testMap[j][i] == 4)
                {
                    // Color of the head of robot
                    canvas.drawRect(i * cellWidth, j * cellHeight, (i + 1) * cellWidth, (j + 1) * cellHeight, robotPaint);
                    /*if (i > 0 && i < 14 && j > 0 && j < 19) {
                        path.moveTo((i*cellWidth) + halfWidth, (j*cellHeight) - cellHeight); // Top
                        path.lineTo((i*cellWidth) - cellWidth, (j*cellHeight) + (2*cellHeight)); // Bottom left
                        path.lineTo((i*cellWidth) + (2*cellWidth), (j*cellHeight) + (2*cellHeight)); // Bottom right
                        path.lineTo((i*cellWidth) + halfWidth, (j*cellHeight) - cellHeight); // Back to Top
                        path.close();
                        canvas.drawPath(path, robotPaint);
                    }*/
                }

                if(testMap[j][i] == 8) {
                    // Color of the waypoint selected
                    canvas.drawRect(i * cellWidth, j * cellHeight, (i + 1) * cellWidth, (j + 1) * cellHeight, waypointPaint);
                }
/*
                if (testMap[j][i] == 1 && j == 17 && i == 12) {
                    canvas.drawRect(i * cellWidth, j * cellHeight, (i + 1) * cellWidth, (j + 1) * cellHeight, goalZone);
                }

                if (testMap[j][i] == 1 && j == 18 && i == 13) {
                    canvas.drawRect(i * cellWidth, j * cellHeight, (i + 1) * cellWidth, (j + 1) * cellHeight, goalZone);
                }

                if (testMap[j][i] == 1 && j == 19 && i == 14) {
                    canvas.drawRect(i * cellWidth, j * cellHeight, (i + 1) * cellWidth, (j + 1) * cellHeight, goalZone);
                }
*/

                // When is this executed?
                if(startCellChecked[i][j]){
                    if (i > 0 && i < 14 && j > 0 && j < 19) {
                        path.moveTo((i*cellWidth) + halfWidth, (j*cellHeight) - cellHeight); // Top
                        path.lineTo((i*cellWidth) - cellWidth, (j*cellHeight) + (2*cellHeight)); // Bottom left
                        path.lineTo((i*cellWidth) + (2*cellWidth), (j*cellHeight) + (2*cellHeight)); // Bottom right
                        path.lineTo((i*cellWidth) + halfWidth, (j*cellHeight) - cellHeight); // Back to Top
                        path.close();
                        canvas.drawPath(path, robotPaint);
                    }
                   /* path.moveTo((i*cellWidth) + halfWidth, (j*cellHeight)); // Top
                    path.lineTo((i*cellWidth), (j*cellHeight) + cellHeight); // Bottom left
                    path.lineTo((i*cellWidth) + cellWidth, (j*cellHeight) + cellHeight); // Bottom right
                    path.lineTo((i*cellWidth) + halfWidth, (j*cellHeight)); // Back to Top
                    path.close();
                    canvas.drawPath(path, robotPaint);*/
                }
                if (cellChecked[i][j]) {

                    /*path.moveTo(i + halfWidth, j); // Top
                    path.lineTo(i, j + cellWidth); // Bottom left
                    path.lineTo(i + cellWidth, j + cellWidth); // Bottom right
                    path.lineTo(i + halfWidth, j); // Back to Top
                    path.close();
                    canvas.drawPath(path, robotPaint);*/

                    /*canvas.drawRect(i * cellWidth, j * cellHeight,
                            (i + 1) * cellWidth, (j + 1) * cellHeight,

                            greenPaint);

                            blackPaint); */

                }
            }
        }


        // Draw the text, with origin at (x,y), using the specified paint.
        //canvas.drawText("START", (1-1)*cellHeight, (19-0)*cellHeight, paint);
        //canvas.drawText("GOAL", (11)*cellHeight, (2)*cellHeight, paint);

        // ======== Drawing lines for columns and rows ============
        for (int i = 1; i <= numColumns; i++) {
            canvas.drawLine(i * cellWidth, 0, i * cellWidth, height, blackPaint);
        }

        for (int i = 1; i <= numRows; i++) {
            canvas.drawLine(0, i * cellHeight, width, i * cellHeight, blackPaint);
        }


        // ======== Placing arrows ============
        if(arrowpost){
            int x  = arrowCoord[0];		// X axis of arrow
            int y  = arrowCoord[1];		// Y axis of arrow
            int d = arrowCoord[2];		// Direction of arrow head

            // Add each of the values into respective array
            arx.add(x);
            ary.add(y);
            ard.add(d);

            // Display as the arrow
            myImg = BitmapFactory.decodeResource(getResources(), R.drawable.arrow);

            // Resize the arrow to approriate size and display at the cell
            for(int i=0;i<arx.size();i++) {
                Bitmap scaledImg = getResizedBitmap(myImg,ard.get(i));
                canvas.drawBitmap(scaledImg,(arx.get(i)*cellWidth)+5,(ary.get(i)*cellHeight)+10,null);
            }
        }

        // Remove the arrow from the grid map, draw back original rectangle. This is executed when clear the map
        if(deleteBitmap){
            myImg = BitmapFactory.decodeResource(getResources(), R.drawable.rectangle);
            for(int i=0;i<arx.size();i++) {
                Bitmap scaledImg = getResizedBitmap(myImg, ard.get(i));
                canvas.drawBitmap(scaledImg, (arx.get(i) * cellWidth) + 5, (ary.get(i) * cellHeight) + 10, null);
            }
        }
    }

    // Resize the arrow image, will switch the arrow head to approriate direction
    public Bitmap getResizedBitmap(Bitmap bm,int direction) {
        int width = bm.getWidth();
        int height = bm.getHeight();
        // Change these two float values to resize the image
        float scaleWidth = (float)0.05620991;//(float)0.07620991;
        float scaleHeight = (float)0.05620991;//0.07620991;
        // CREATE A MATRIX FOR THE MANIPULATION
        Matrix matrix = new Matrix();
        // RESIZE THE BIT MAP
        matrix.postScale(scaleWidth, scaleHeight);
        switch (direction){
            case 0:
                matrix.postRotate(0);
                break;
            case 1:
                matrix.postRotate(90);
                break;
            case 2:
                matrix.postRotate(180);
                break;
            case 3:
                matrix.postRotate(270);
                break;
            default:
                break;
        }

        // "RECREATE" THE NEW BITMAP
        Bitmap resizedBitmap = Bitmap.createBitmap(
                bm, 0, 0, width, height, matrix, false);
        return resizedBitmap;
    }

    // Clear the map
    public void clearMap(){
        md.clearMapArray();
        deleteBitmap = true;
        arrowpost = false;
        arx.clear();
        ary.clear();
        ard.clear();
    }

    // Show Waypoint
    public void wpShow(){
        md.showWp();
    }

    // Hide Waypoint
    public void wpHide(){
        md.hideWp();
    }

    // Set Waypoint
    public void setWaypoint(int x,int y){
        md.updateWaypoint(y,x);
    }

    // Update Waypoint
    public void updateArena(String exploredMap, String obstacleMap){
        md.updateMapArray(exploredMap,obstacleMap);
    }

    // Update actual robot position
    public void updateRobotPos(String robotPos){
        md.updateRobotPos(robotPos);
    }

    // Call the method to get the arrow head direction
    public void getArrowPosition(String arrowPost){
        arrowCoord = md.decodeArrowPosition(arrowPost);
        //MainActivity.setCoordinates(arrowCoord[0],arrowCoord[1]);
    }

    // When is this used?
    public void setCellchecked(int x, int y){
        cellChecked[x][y] = !cellChecked[x][y];
        invalidate();
    }

    public void updateDemoArenaMap(String obstacleMapDes){
        md.updateDemoMapArray(obstacleMapDes);
    }


    public void updateDemoRobotPos(String robotPos){
        md.updateDemoRobotPos(robotPos);
    }

    public void setStartPoint(int x, int y){
        startCellChecked[x][y] = true;
        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            int column = (int)(event.getX() / cellWidth);
            int row = (int)(event.getY() / cellHeight);

            //cellChecked[column][row];
            MainActivity.setCoordinates(column,19-row);
            invalidate();
        }
        return true;
    }
}
