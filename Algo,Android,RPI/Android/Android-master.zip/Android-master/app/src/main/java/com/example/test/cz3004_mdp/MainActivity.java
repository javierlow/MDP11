package com.example.test.cz3004_mdp;

import android.Manifest;
import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import android.widget.Toolbar;

import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private static final String TAG = "MainActivity";

    Boolean connectStatus = false;
    Boolean BTStartConnectionStatus = false;

    BluetoothAdapter mBluetoothAdapter;
    // For showing pop up when discovering devices
    AlertDialog bt_dialog, configString_dialog;
    LayoutInflater inflater;

    // Hold the Bluetooth Devices discovered
    public ArrayList<BluetoothDevice> mBTDevices = new ArrayList<>();

    // For Devices List View
    public DeviceListAdapter mDeviceListAdapter;
    ListView lvNewDevices;
    // For Paired Devices
    ListView lvPairedDevices;

    // Array to Hold all Paired Devices
    public ArrayList<BluetoothDevice> mPairedBTDevices = new ArrayList<>();
    public DeviceListAdapter mPairedDeviceListAdapter;

    TextView tvBTStatus;
    TextView noDevicesTV, noPairedTV;

    // For transmit string
    Button btnStartConnection, btnSend;
    TextView tvCommandsReceived, outgoingMessagesTV, tvCommandsSent, tvArrowStringReceived;
    StringBuilder messages, commandsSentMessages, arrowStringMessages;
    EditText etSend;
    StringBuilder outgoingMessages = new StringBuilder();
    private static final UUID MY_UUID_INSECURE = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    BluetoothDevice mBTDevice = null;
    BluetoothConnectionService mBluetoothConnection;

    // For Map
    Robot robot;
    PixelGridView pixelGridView;
    MapDecoder md;
    LinearLayout maze;
    ImageButton upBtn, downBtn, rightBtn, leftBtn;
    TextView tvRobotStatus, startXY, waypointXY;
    public static TextView tvXCoor, tvYCoor;
    Switch switchAutoManual;
    Button updateBtn;
    public boolean isAutoUpdate = true;
    public boolean listenForUpdate = false;
    TextView tvAutoManual;
    private String storedMsg;

    SharedPreferences myPrefs;
    //StringBuilder configHistory;

    // Fastest and Exploration
    private boolean stillExplore = false;
    private boolean stillFast = false;
    // variables for timer
    long startExploreTime = 0;
    long startFastTime =0;
    Button startStopBtn;
    TextView fastestreceiveTV, explorationreceiveTV, tvPath, tvMDFExploreReceived, tvMDFFastestReceived;
    Switch switchPath;

    // Sensor
    private SensorManager sensorManager;
    private Sensor sensor;
    private SensorManager mSensorManager;
    private Sensor mAccelerometer;
    private Sensor mMagnetometer;
    private float[] mR = new float[9];
    private float[] mOrientation = new float[3];
    private long lastUpdate;
    private float[] mLastAccelerometer = new float[3];
    private float[] mLastMagnetometer = new float[3];
    private boolean mLastAccelerometerSet = false;
    private boolean mLastMagnetometerSet = false;
    Switch switchTilt;
    TextView tvTilt, tvMovement;

    private final static int REQUEST_ENABLE_BT = 1;

    // Robust Bluetooth
    BluetoothDevice mPrevBTDevice = null;

    private Sensor accelerometer;
    private SensorManager SM;
    private boolean tilt = false;
    private boolean startup_tilt = true;
    private float ref_tilt = 0;
    private int pre_state = 0;

    // Create a BroadcastReceiver for ACTION_FOUND
    private final BroadcastReceiver mBroadcastReceiver1 = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            // When discovery finds a device
            if (action.equals(mBluetoothAdapter.ACTION_STATE_CHANGED)) {
                final int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, mBluetoothAdapter.ERROR);

                switch(state){
                    case BluetoothAdapter.STATE_OFF:
                        Log.d(TAG, "onReceive: STATE OFF");
                        break;
                    case BluetoothAdapter.STATE_TURNING_OFF:
                        Log.d(TAG, "mBroadcastReceiver1: STATE TURNING OFF");
                        break;
                    case BluetoothAdapter.STATE_ON:
                        Log.d(TAG, "mBroadcastReceiver1: STATE ON");
                        break;
                    case BluetoothAdapter.STATE_TURNING_ON:
                        Log.d(TAG, "mBroadcastReceiver1: STATE TURNING ON");
                        break;
                }
            }
        }
    };

    /**
     * Broadcast Receiver for changes made to bluetooth states such as:
     * 1) Discoverability mode on/off or expire.
     **/
    private final BroadcastReceiver mBroadcastReceiver2 = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();

            if (action.equals(BluetoothAdapter.ACTION_SCAN_MODE_CHANGED)) {

                int mode = intent.getIntExtra(BluetoothAdapter.EXTRA_SCAN_MODE, BluetoothAdapter.ERROR);

                switch (mode) {
                    //Device is in Discoverable Mode
                    case BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE:
                        Log.d(TAG, "mBroadcastReceiver2: Discoverability Enabled.");
                        break;
                    //Device not in discoverable mode
                    case BluetoothAdapter.SCAN_MODE_CONNECTABLE:
                        Log.d(TAG, "mBroadcastReceiver2: Discoverability Disabled. Able to receive connections.");
                        break;
                    case BluetoothAdapter.SCAN_MODE_NONE:
                        Log.d(TAG, "mBroadcastReceiver2: Discoverability Disabled. Not able to receive connections.");
                        break;
                    case BluetoothAdapter.STATE_CONNECTING:
                        Log.d(TAG, "mBroadcastReceiver2: Connecting....");
                        break;
                    case BluetoothAdapter.STATE_CONNECTED:
                        Log.d(TAG, "mBroadcastReceiver2: Connected.");
                        break;
                }
            }
        }
    };

    /**
     * Broadcast Receiver for listing devices that are not yet paired
     * -Executed by btnDiscover() method.
     */
    private BroadcastReceiver mBroadcastReceiver3 = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            Log.d(TAG, "onReceive: ACTION FOUND.");

            // Retrieve all previously paired devices
            Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();

            mDeviceListAdapter = new DeviceListAdapter(context, R.layout.device_adapter_view, mBTDevices);
            mPairedDeviceListAdapter = new DeviceListAdapter(context, R.layout.device_adapter_view, mPairedBTDevices);
            //mPairedDeviceListAdapter = new DeviceListAdapter(MainActivity.this, R.layout.device_adapter_view, mPairedBTDevices);

            if (pairedDevices.size() > 0) {
                for (BluetoothDevice device : pairedDevices) {
                    // If the device is already in Paired Device List, just ignore
                    if (mPairedBTDevices.contains(device)) {
                        Log.d(TAG, "onReceive: " + device.getName() + " " + device.getAddress() + " already exist in paired list.");
                    }
                    // Else add into Paired Device List
                    else {
                        mPairedBTDevices.add(device);
                        //lvPairedDevices.setAdapter(mPairedDeviceListAdapter);
                    }
                }
            }
            lvPairedDevices.setAdapter(mPairedDeviceListAdapter);

            /*
            if (pairedDevices.size() > 0) {
                // Foreach device in PairedDevices
                for (BluetoothDevice device : pairedDevices) {
                    // If the device is already in Paired Device List, just ignore
                    if (mPairedBTDevices.contains(device)) {
                        Log.d(TAG, "onReceive: " + device.getName() + " " + device.getAddress() + " already exist in paired list.");
                    }
                    // Else add into Paired Device List
                    else {
                        mPairedBTDevices.add(device);
                        lvPairedDevices.setAdapter(mPairedDeviceListAdapter);
                    }
                }
            }
            */

            if (action.equals(BluetoothDevice.ACTION_FOUND)) {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);

                // If device found already paired before, ignore
                if (pairedDevices.contains(device)) {
                    Log.d(TAG, "onReceive: " + device.getName() + " " + device.getAddress() + " already exist.");
                } else {
                    // If device found is not in the new device list
                    if (!mBTDevices.contains(device)) {
                        mBTDevices.add(device);
                        Log.d(TAG, "onReceive: " + device.getName() + ": " + device.getAddress());
                        lvNewDevices.setAdapter(mDeviceListAdapter);
                    } else {
                        Log.d(TAG, "onReceive: " + device.getName() + " " + device.getAddress() + " already exist.");
                    }
                }
            } else if (mBluetoothAdapter.isEnabled() && action.equals(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)) {

                if (mPairedBTDevices.size() > 0) {
                    lvPairedDevices.setAdapter(mPairedDeviceListAdapter);
                }
                //Log.d(TAG, "SEE COUNT HERE : " + mDeviceListAdapter.getCount() + " AND : " + mPairedDeviceListAdapter.getCount());
                // Indicate scanning in the title
                //progressBar.setVisibility(View.GONE);
                Toast.makeText(MainActivity.this, "Discovery Finished", Toast.LENGTH_SHORT).show();
                /* if (mBTDevices.size() == 0) {
                    noDevicesTV.setVisibility(View.VISIBLE);
                }
                if(mPairedBTDevices.size() == 0){
                    noPairedTV.setVisibility(View.VISIBLE);
                } */
            }
        }
    };

    /**
     * Broadcast Receiver that detects bond state changes (Pairing status changes)
     */
    private final BroadcastReceiver mBroadcastReceiver4 = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();

            if(action.equals(BluetoothDevice.ACTION_BOND_STATE_CHANGED)){
                BluetoothDevice mDevice = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                //3 cases:
                //case1: bonded already
                if (mDevice.getBondState() == BluetoothDevice.BOND_BONDED){
                    Log.d(TAG, "BroadcastReceiver: BOND_BONDED.");

                    //assigning global bluetooth device to device
                    mBTDevice = mDevice;
                    Log.d(TAG, "Bluetooth Device bonded: " + mDevice.getName());

                    mPairedBTDevices.add(mDevice);
                    mPairedDeviceListAdapter = new DeviceListAdapter(MainActivity.this, R.layout.device_adapter_view, mPairedBTDevices);
                    lvPairedDevices.setAdapter(mPairedDeviceListAdapter);

                    mBTDevices.remove(mDevice);
                    mDeviceListAdapter = new DeviceListAdapter(MainActivity.this, R.layout.device_adapter_view, mBTDevices);
                    lvNewDevices.setAdapter(mDeviceListAdapter);

                    mBluetoothConnection = new BluetoothConnectionService(MainActivity.this);
                    startBTConnection(mBTDevice, MY_UUID_INSECURE);

                }
                //case2: creating a bone
                if (mDevice.getBondState() == BluetoothDevice.BOND_BONDING) {
                    Log.d(TAG, "BroadcastReceiver: BOND_BONDING.");
                }
                //case3: breaking a bond
                if (mDevice.getBondState() == BluetoothDevice.BOND_NONE) {
                    Log.d(TAG, "BroadcastReceiver: BOND_NONE.");
                }
            }
        }
    };



    @Override
    protected void onDestroy() {
        Log.d(TAG, "onDestroy: called.");
        super.onDestroy();
        unregisterReceiver(mBroadcastReceiver1);
        try {
            unregisterReceiver(mBroadcastReceiver2);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        unregisterReceiver(mBroadcastReceiver3);
        unregisterReceiver(mBroadcastReceiver4);
        unregisterReceiver(mBroadcastReceiver5);
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mBroadcastReceiver2);
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mReceiver);
        //unregisterReceiver(mReceiver);
        //mBluetoothAdapter.cancelDiscovery();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.bluetooth:
                enableDisableBT();
                return true;
            case R.id.enableDiscovery:
                enableDisableDiscoverable();
                return true;
            case R.id.Discover:
                if (mBluetoothAdapter.isEnabled()) {
                    AlertDialog.Builder bt_dialog = showBluetoothDevices();
                    bt_dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                        @Override
                        public void onDismiss(DialogInterface dialog) {
                            mBluetoothAdapter.cancelDiscovery();
                        }
                    });
                    this.bt_dialog = bt_dialog.show();
                }
                else {
                    Toast.makeText(this, "Please turn on bluetooth", Toast.LENGTH_SHORT).show();
                }
                return true;
            case R.id.configString:
                if (mBluetoothAdapter.isEnabled()) {
                    AlertDialog.Builder configString_dialog = showConfigString();
                    /* configString_dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                        @Override
                        public void onDismiss(DialogInterface dialog) {
                            mBluetoothAdapter.cancelDiscovery();
                        }
                    }); */
                    this.configString_dialog = configString_dialog.show();
                }
                else {
                    Toast.makeText(this, "Please turn on bluetooth", Toast.LENGTH_SHORT).show();
                }
                return true;
            /*
            case R.id.calibrate:
                if(mBTDevice!= null){
                    String calibrate = "Pca";
                    byte[] bytes = calibrate.getBytes(Charset.defaultCharset());
                    if(mBluetoothConnection != null){
                        mBluetoothConnection.write(bytes);
                        commandsSentMessages.append(calibrate + ": CALIBRATING" + "\n");
                        tvCommandsSent.setText(commandsSentMessages);
                    }
                    else{
                        mBluetoothConnection.write(bytes);
                        commandsSentMessages.append(calibrate + ": CALIBRATING" + "\n");
                        tvCommandsSent.setText(commandsSentMessages);
                    }
                } */
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SM = (SensorManager) getSystemService(SENSOR_SERVICE);
        accelerometer = SM.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        // Checking of Permissions
        int ACTION_REQUEST_MULTIPLE_PERMISSION = 1;  // Any number
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            int pCheck = this.checkSelfPermission("Manifest.permission.ACCESS_FINE_LOCATION");
            pCheck += this.checkSelfPermission("Manifest.permission.ACCESS_COARSE_LOCATION");
            pCheck += this.checkSelfPermission("Manifest.permission.BLUETOOTH_ADMIN");
            pCheck += this.checkSelfPermission("Manifest.permission.BLUETOOTH");
            if(pCheck != 0){
                this.requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.BLUETOOTH_ADMIN, Manifest.permission.BLUETOOTH}, ACTION_REQUEST_MULTIPLE_PERMISSION);
                Log.d(TAG, "Permissions granted");
            }
        }

        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        lvNewDevices = (ListView) findViewById(R.id.lvNewDevices);
        lvPairedDevices = (ListView) findViewById(R.id.lvPairedDevices);
        mBTDevices = new ArrayList<>();
        mPairedBTDevices = new ArrayList<>();
        tvBTStatus = (TextView) findViewById(R.id.tvBTStatus);

        // For transmit data
        //btnStartConnection = (Button) findViewById(R.id.btnStartConnection);
        //btnSend = (Button) findViewById(R.id.btnSend);
        //etSend = (EditText) findViewById(R.id.editText);

        tvCommandsReceived = (TextView) findViewById(R.id.tvCommandsReceived);
        tvCommandsReceived.setMovementMethod(new ScrollingMovementMethod());
        messages = new StringBuilder();

        tvCommandsSent = (TextView) findViewById(R.id.tvCommandsSent);
        tvCommandsSent.setMovementMethod(new ScrollingMovementMethod());
        commandsSentMessages = new StringBuilder();

        tvArrowStringReceived = (TextView) findViewById(R.id.tvArrowStringReceived);
        tvArrowStringReceived.setMovementMethod(new ScrollingMovementMethod());
        arrowStringMessages = new StringBuilder();

        LocalBroadcastManager.getInstance(this).registerReceiver(mReceiver, new IntentFilter("incomingMessage"));

        //outgoingMessagesTV = (TextView) findViewById(R.id.outgoingMessage);
        //outgoingMessagesTV.setMovementMethod(new ScrollingMovementMethod());

        tvMDFExploreReceived = (TextView) findViewById(R.id.tvMDFExploreReceived);
        tvMDFFastestReceived = (TextView) findViewById(R.id.tvMDFFastestReceived);

        inflater = LayoutInflater.from(this);

        // For Map
        maze = (LinearLayout) findViewById(R.id.maze);
        maze.getViewTreeObserver().addOnGlobalLayoutListener(new MyGlobalListenerClass());
        //direction buttons
        upBtn = (ImageButton) findViewById(R.id.upBtn);
        downBtn = (ImageButton) findViewById(R.id.downBtn);
        rightBtn = (ImageButton) findViewById(R.id.rightBtn);
        leftBtn = (ImageButton) findViewById(R.id.leftBtn);
        tvRobotStatus = (TextView) findViewById(R.id.tvRobotStatus);
        robot = new Robot(1,1,"NORTH");
        tvXCoor = (TextView) findViewById(R.id.tvXCoor);
        tvYCoor = (TextView) findViewById(R.id.tvYCoor);
        startXY = (TextView) findViewById(R.id.startXY);
        waypointXY = (TextView) findViewById(R.id.waypointXY);
        switchAutoManual = (Switch) findViewById(R.id.switchAutoManual);
        tvAutoManual = (TextView) findViewById(R.id.tvAutoManual);
        updateBtn = (Button) findViewById(R.id.updateBtn);

        // For Fastest and Exploration
        //fastestBtn = (Button) findViewById(R.id.fastestBtn);
        fastestreceiveTV = (TextView) findViewById(R.id.fastestreceiveTV);
        startStopBtn = (Button) findViewById(R.id.startStopBtn);
        explorationreceiveTV = (TextView) findViewById(R.id.explorationreceiveTV);
        switchPath = (Switch) findViewById(R.id.switchPath);
        tvPath = (TextView) findViewById(R.id.tvPath);
        // Set default value
        tvPath.setText("Explore");

        // Sensor
        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        mAccelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        mMagnetometer = mSensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        switchTilt = (Switch) findViewById(R.id.switchTilt);
        tvTilt = (TextView) findViewById(R.id.tvTilt);
        tvMovement = (TextView) findViewById(R.id.tvMovement);

        //Broadcasts when bond state changes (ie:pairing)
        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
        registerReceiver(mBroadcastReceiver4, filter);

        // Register for broadcasts when discovery has finished
        IntentFilter filter3 = new IntentFilter(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        this.registerReceiver(mBroadcastReceiver3, filter3);

        // Register for broadcasts when a device is discovered.
        IntentFilter filter1 = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        registerReceiver(mBroadcastReceiver1, filter1);

        //to track if the bluetooth is connected to any device or not
        IntentFilter filter2 = new IntentFilter();
        filter2.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
        filter2.addAction(BluetoothDevice.ACTION_ACL_DISCONNECT_REQUESTED);
        filter2.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);
        this.registerReceiver(mBroadcastReceiver5, filter2);

        checkBTStatus();

        /* Transmit data
        btnStartConnection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startConnection();
                Log.d(TAG, "startConnection.");
            }
        });

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (connectStatus = true) {
                    byte[] bytes = etSend.getText().toString().getBytes(Charset.defaultCharset());
                    mBluetoothConnection.write(bytes);
                    //display out going messages
                    outgoingMessages.append(etSend.getText() + "\n");
                    outgoingMessagesTV.setText(outgoingMessages);
                    Log.d(TAG, "here " + etSend.getText().toString());
                    etSend.setText("");
                }
                else {
                    Toast.makeText(MainActivity.this, "Please connect to BT", Toast.LENGTH_SHORT).show();
                }
            }
        }); */

        switchAutoManual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            if (switchAutoManual.isChecked()) {
                updateBtn.setEnabled(false);
                isAutoUpdate = true;
                tvAutoManual.setText("Auto");
                Toast.makeText(MainActivity.this, "Switch to Auto Mode", Toast.LENGTH_LONG).show(); // display the current state for switch's
            }
            else {
                updateBtn.setEnabled(true);
                isAutoUpdate = false;
                tvAutoManual.setText("Manual");
                Toast.makeText(MainActivity.this, "Switch to Manual Mode", Toast.LENGTH_LONG).show(); // display the current state for switch's
            }
            }
        });

        switchTilt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (switchTilt.isChecked()) {
                    tvTilt.setText("On");
                    SM.registerListener(MainActivity.this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
                    Toast.makeText(MainActivity.this, "Tilt On", Toast.LENGTH_LONG).show(); // display the current state for switch's
                }
                else {
                    tvTilt.setText("Off");
                    SM.unregisterListener(MainActivity.this);
                    Toast.makeText(MainActivity.this, "Tilt Off", Toast.LENGTH_LONG).show(); // display the current state for switch's
                }
            }
        });

        switchPath.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (switchPath.isChecked()) {
                    tvPath.setText("Explore");
                    Toast.makeText(MainActivity.this, "Exploration On", Toast.LENGTH_LONG).show(); // display the current state for switch's
                }
                else {
                    tvPath.setText("Fastest");
                    Toast.makeText(MainActivity.this, "Fastest On", Toast.LENGTH_LONG).show(); // display the current state for switch's
                }
            }
        });
    }

    // for transmit data
    /* create method for starting connection, remember the connection will fail and app will crash if you havent paired first*/
    public void startConnection(){
        if(mBTDevice == null){
            BTStartConnectionStatus  = false;
            Toast.makeText(MainActivity.this,"Please connect to a device first! ", Toast.LENGTH_SHORT).show();
        }
        else{
            BTStartConnectionStatus = true;
            startBTConnection(mBTDevice,MY_UUID_INSECURE);
        }
        checkBTStatus();
    }
    /* starting chat service method */
    public void startBTConnection(BluetoothDevice device, UUID uuid){
        Log.d(TAG, "startBTConnection: Initializing RFCOM Bluetooth Connection. ");
        mBluetoothConnection.connect(device, true);
    }

    // a broadcast receiver to handle incoming messages
    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String text = intent.getStringExtra("theMessage");
            //messages.append(text)
            //tvCommandsReceived.setText(text);

            // for status update, need to change
            if (text.equals("exploring") || text.equals("fastest path") || text.equals("turning left") ||
                    text.equals("turning right") || text.equals("moving forward") || text.equals("reversing")) {

                if (text.equals("turning right")) {
                    String position = robot.getPosition();
                    String direction = robot.getDirection();
                    String grid[] = position.split(",");
                    int x = Integer.parseInt(grid[0]);
                    int y = Integer.parseInt(grid[1]);
                    turnRightMovement(x,y,direction);
                    tvRobotStatus.setText(text.toUpperCase());
                    messages.append(text + "\n");
                    tvCommandsReceived.setText(messages.toString().toUpperCase());
                }
                if (text.equals("turning left")) {
                    String position = robot.getPosition();
                    String direction = robot.getDirection();
                    String grid[] = position.split(",");
                    int x = Integer.parseInt(grid[0]);
                    int y = Integer.parseInt(grid[1]);
                    turnLeftMovement(x,y,direction);
                    tvRobotStatus.setText(text.toUpperCase());
                    messages.append(text + "\n");
                    tvCommandsReceived.setText(messages.toString().toUpperCase());
                }
                if (text.equals("moving forward")) {
                    String position = robot.getPosition();
                    String direction = robot.getDirection();
                    String grid[] = position.split(",");
                    int x = Integer.parseInt(grid[0]);
                    int y = Integer.parseInt(grid[1]);
                    forwardMovement(x,y,direction);
                    //statusReceived = "moving forward";
                    tvRobotStatus.setText(text.toUpperCase());
                    messages.append(text + "\n");
                    tvCommandsReceived.setText(messages.toString().toUpperCase());
                }
                if (text.equals("reversing")) {
                    //statusReceived= "reversing";
                    String position = robot.getPosition();
                    String direction = robot.getDirection();
                    String grid[] = position.split(",");
                    int x = Integer.parseInt(grid[0]);
                    int y = Integer.parseInt(grid[1]);
                    reverseMovement(x,y,direction);
                    tvRobotStatus.setText(text.toUpperCase());
                    messages.append(text + "\n");
                    tvCommandsReceived.setText(messages.toString().toUpperCase());
                }
            }

            // Arrow position from RPI
            if (text.contains("xA:")) {
                // if (isAutoUpdate == true || listenForUpdate == true) {
                    pixelGridView.arrowpost = true;
                    pixelGridView.getArrowPosition(text);
                    arrowStringMessages.append(text + "\n");
                    tvArrowStringReceived.setText(arrowStringMessages.toString().toUpperCase());
                    pixelGridView.invalidate();
                //    listenForUpdate=false;
                /* }
                else{
                    messages.append("INVALID ARROW POSITION" + "\n");
                    pixelGridView.arrowpost = false;
                }  */
            }

            /* For getting arrow position, need to change
            if(text.contains("arrowPosition")) {
                if (isAutoUpdate == true || listenForUpdate == true) {
                    pixelGridView.arrowpost = true;
                    pixelGridView.getArrowPosition(text);
                    messages.append(text + "\n");
                    tvCommandsReceived.setText(messages.toString().toUpperCase());
                    pixelGridView.invalidate();
                    listenForUpdate=false;
                }
                else{
                    messages.append("INVALID ARROW POSITION" + "\n");
                    pixelGridView.arrowpost = false;
                }
            } */

            if(text.contains("endExplore")){
                stillExplore=false;
                startStopBtn.setText("Start");
                switchPath.setEnabled(true);
                enableDirection();

                // Stop timer
                stillExplore = false;
                startExploreTime = System.currentTimeMillis();
                timerHandlerExplore.postDelayed(timerRunnableExplore, 0);

                messages.append("END EXPLORATION PATH" + "\n");
                tvCommandsReceived.setText(messages.toString().toUpperCase());
            }

            if(text.contains("endFastest")){
                stillFast=false;
                startStopBtn.setText("Start");
                switchPath.setEnabled(true);
                enableDirection();

                // Stop timer
                stillFast = false;
                startFastTime = System.currentTimeMillis();
                timerHandlerFastest.postDelayed(timerRunnableFastest, 0);

                messages.append("END FASTEST PATH" + "\n");
                tvCommandsReceived.setText(messages.toString().toUpperCase());
            }

            // ============ This code is for actual update of map ==================
            String text1 = tvAutoManual.getText().toString();
            // receive format MDF|current_y|current_x|robotfacing|exploredStr|obstacleStr
            if(text.contains("MDF")){
                String grid[] = text.split("\\|");
                //y|x|direction
                String position = grid[1]+"|"+grid[2]+"|"+grid[3];
                if(text1.equals("Auto")){
                    robot.setPosition(Integer.parseInt(grid[2]), Integer.parseInt(grid[1]));
                    robot.setDirection(grid[3]);
                    String exploredMap = grid[4];
                    String obstacleMap = grid[5];
                    if(exploredMap.matches("^[0-9a-fA-F]+$") && obstacleMap.matches("^[0-9a-fA-F]+$")){

                        tvMDFExploreReceived.setText(exploredMap);
                        tvMDFFastestReceived.setText(obstacleMap);

                        pixelGridView.updateRobotPos(position);
                        pixelGridView.updateArena(exploredMap,obstacleMap);
                        pixelGridView.invalidate();
                        //p1String.setText(exploredMap);
                        //p2String.setText(obstacleMap);
                    }
                    else{
                        Toast.makeText(MainActivity.this, "Incorrect String format", Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    storedMsg = text;
                }
            }
            // ================== END ===================== */

            // =========== FROM HERE, ONLY USED FOR AMD TESTING I THINK =========
            byte[] read = text.getBytes();
            String mpInfo = new String(read);
            if (mpInfo.contains("grid")){
                if(isAutoUpdate==true || listenForUpdate==true) {
                    try {
                        JSONObject obj = new JSONObject(mpInfo);
                        String mpUp = obj.getString("grid");
                        Log.d(TAG, "mpUp = " + mpUp);
                        pixelGridView.updateDemoArenaMap(mpUp);
                        pixelGridView.invalidate();
                        listenForUpdate=false;
                    } catch (JSONException e) {
                        e.printStackTrace();

                    }
                }
            }

            if(mpInfo.contains("robotPosition")) {
                if (isAutoUpdate == true || listenForUpdate == true) {
                    //update robot position
                    pixelGridView.updateDemoRobotPos(mpInfo);
                    pixelGridView.invalidate();
                    listenForUpdate=false;
                }
                else{
                    storedMsg=mpInfo;
                }
            }
            // =========== AMD TESTING END HERE ===============
        } //END
    };

    private final BroadcastReceiver mBroadcastReceiver5 = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
             String action = intent.getAction();

            BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
            String deviceName = device.getName();

            if(BluetoothDevice.ACTION_ACL_CONNECTED.equals(action)) {
                connectStatus = true;
                //mBTDevice = mBluetoothConnection.getDevice();
                mPrevBTDevice = mBTDevice;
                Toast.makeText(MainActivity.this, "Connected to: "+ deviceName, Toast.LENGTH_SHORT).show();
            }
            else if(BluetoothDevice.ACTION_ACL_DISCONNECT_REQUESTED.equals(action)){
                Toast.makeText(MainActivity.this, "BT about to disconnected from: " + deviceName, Toast.LENGTH_SHORT).show();
            }
            else if (BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(action)) {
                connectStatus = false;
                Toast.makeText(MainActivity.this, "Disconnected from: " + deviceName, Toast.LENGTH_SHORT).show();
                Log.d(TAG, "Check this 1" + mBluetoothConnection);
            }
            checkBTStatus();
        }
    };

    public void enableDisableBT(){
        // Device doesn't support Bluetooth
        if(mBluetoothAdapter == null){
            Log.d(TAG, "enableDisableBT: Does not have BT capabilities.");
        }
        // Enable Bluetooth if it is not yet enabled
        if(!mBluetoothAdapter.isEnabled()){
            Log.d(TAG, "enableDisableBT: enabling BT.");

            // Issues a request to enable Bluetooth through the system settings
            Intent enableBTIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBTIntent, REQUEST_ENABLE_BT);
        }
        // Disable Bluetooth if it is already enabled
        if(mBluetoothAdapter.isEnabled()){
            Log.d(TAG, "enableDisableBT: disabling BT.");
            mBluetoothAdapter.disable();

            if (lvNewDevices != null) {
                lvNewDevices.setAdapter(null);
            }

            if (lvPairedDevices != null) {
                lvPairedDevices.setAdapter(null);
            }

            IntentFilter BTIntent = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
            registerReceiver(mBroadcastReceiver1, BTIntent);
        }
    }

    public void btnEnableDisable_Discoverable(View view) {
        Log.d(TAG, "btnEnableDisable_Discoverable: Making device discoverable for 300 seconds.");

        // Sets the device to be discoverable for 5 minutes (300 seconds)
        // Note: If Bluetooth has not been enabled on the device, then making the device discoverable automatically enables Bluetooth.
        Intent discoverableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
        discoverableIntent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
        startActivity(discoverableIntent);

        IntentFilter intentFilter = new IntentFilter(mBluetoothAdapter.ACTION_SCAN_MODE_CHANGED);
        registerReceiver(mBroadcastReceiver2,intentFilter);
    }

    public void enableDisableDiscoverable() {
        // Sets the device to be discoverable for 5 minutes (300 seconds)
        // Note: If Bluetooth has not been enabled on the device, then making the device discoverable automatically enables Bluetooth.
        Intent discoverableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
        discoverableIntent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
        startActivity(discoverableIntent);

        IntentFilter intentFilter = new IntentFilter(mBluetoothAdapter.ACTION_SCAN_MODE_CHANGED);
        registerReceiver(mBroadcastReceiver2,intentFilter);
    }

    public void enableDiscovery() {
        Log.d(TAG, "btnDiscover: Looking for unpaired devices.");

        if (mBluetoothAdapter.isEnabled()) {
            if (mBluetoothAdapter.isDiscovering()) {
                //mBluetoothAdapter.cancelDiscovery();
                Log.d(TAG, "btnDiscover: Canceling discovery.");

                mBluetoothAdapter.startDiscovery();
                IntentFilter discoverDevicesIntent = new IntentFilter(BluetoothDevice.ACTION_FOUND);
                registerReceiver(mBroadcastReceiver3, discoverDevicesIntent);
            }

            if (!mBluetoothAdapter.isDiscovering()) {
                mBluetoothAdapter.startDiscovery();
                IntentFilter discoverDevicesIntent = new IntentFilter(BluetoothDevice.ACTION_FOUND);
                registerReceiver(mBroadcastReceiver3, discoverDevicesIntent);
            }
        }
        else {
            Toast.makeText(this, "Please turn on bluetooth", Toast.LENGTH_SHORT).show();
        }
    }

    // AlertDialog to show pop up when discovering devices
    protected AlertDialog.Builder showBluetoothDevices() {
        enableDiscovery();

        View v = inflater.inflate(R.layout.activity_bluetooth, null);
        lvNewDevices = v.findViewById(R.id.lvNewDevices);
        lvNewDevices.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //first cancel discovery because its very memory intensive.
                //mBluetoothAdapter.cancelDiscovery();

                Log.d(TAG, "onItemClick: You Clicked on a device.");
                String deviceName = mBTDevices.get(i).getName();
                String deviceAddress = mBTDevices.get(i).getAddress();

                Log.d(TAG, "onItemClick: deviceName = " + deviceName);
                Log.d(TAG, "onItemClick: deviceAddress = " + deviceAddress);

                //create the bond.
                if(Build.VERSION.SDK_INT > Build.VERSION_CODES.JELLY_BEAN_MR2) {
                    Log.d(TAG, "Trying to pair with " + deviceName);
                    mBTDevices.get(i).createBond();
                    mBTDevice = mBTDevices.get(i);
                    mBluetoothConnection = new BluetoothConnectionService(MainActivity.this);
                }
                bt_dialog.dismiss();
            }
        });

        lvPairedDevices = v.findViewById(R.id.lvPairedDevices);
        lvPairedDevices.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //first cancel discovery because its very memory intensive.
                //mBluetoothAdapter.cancelDiscovery();

                Log.d(TAG, "onItemClick: You Clicked on a device.");
                String deviceName = mPairedBTDevices.get(i).getName();
                String deviceAddress = mPairedBTDevices.get(i).getAddress();

                Log.d(TAG, "onItemClick: deviceName = " + deviceName);
                Log.d(TAG, "onItemClick: deviceAddress = " + deviceAddress);

                //create the bond.
                if(Build.VERSION.SDK_INT > Build.VERSION_CODES.JELLY_BEAN_MR2){
                    Log.d(TAG, "Trying to pair with " + deviceName);
                    mPairedBTDevices.get(i).createBond();
                    mBTDevice = mPairedBTDevices.get(i); //mBTDevices.get(i);
                    mBluetoothConnection = new BluetoothConnectionService(MainActivity.this);
                    startBTConnection(mPairedBTDevices.get(i), MY_UUID_INSECURE);
                }
              bt_dialog.dismiss();
            }
        });

        v.findViewById(R.id.btnRescan).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                enableDiscovery();
            }
        });
        return new AlertDialog.Builder(this).setView(v);
    }

    public void checkBTStatus() {
        if(mBTDevice != null && connectStatus != false){
            tvBTStatus.setText("Connected to " + mBTDevice.getName());
            Log.d(TAG, "BT checked here");
        }
        else {
            tvBTStatus.setText("Not connected");
        }
    }

    // AlertDialog to show pop up when discovering devices
    protected AlertDialog.Builder showConfigString() {
        // Gets the SharedPreferences
        myPrefs = getSharedPreferences("prefID", Context.MODE_PRIVATE);

        // Gets the values stored, else default value is returned
        String f1 = myPrefs.getString("f1Key","No String Entered");
        String f2 = myPrefs.getString("f2Key","No String Entered");

        View v = inflater.inflate(R.layout.activity_config, null);
        final EditText editF1 = (EditText) v.findViewById(R.id.editF1);
        final EditText editF2 = (EditText) v.findViewById(R.id.editF2);

        //configHistory = new StringBuilder();
        //TextView configHistoryF1F2 = (TextView) findViewById(R.id.tvF1);
        //configHistoryF1F2.setMovementMethod(new ScrollingMovementMethod());

        editF1.setText(f1);
        editF2.setText(f2);

        v.findViewById(R.id.btnSaveConfig).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //if (mBTDevice != null && mBluetoothConnection != null && connectStatus == true) {
                    //set up SharedPreferences
                    myPrefs = getSharedPreferences("prefID", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = myPrefs.edit();

                    Log.d(TAG, "SharedPreferences variables: " + editF1.getText().toString() + " & " + editF2.getText().toString());

                    // store the values into the keys
                    editor.putString("f1Key", editF1.getText().toString());
                    editor.putString("f2Key", editF2.getText().toString());

                    // if storing is successful
                    if (editor.commit()) {
                        /*
                        String configString = "f1=" + editF1.getText().toString() + ",f2=" + editF2.getText().toString();
                        byte[] bytes = configString.getBytes(Charset.defaultCharset());
                        mBluetoothConnection.write(bytes); */

                        configString_dialog.dismiss();
                        Toast.makeText(MainActivity.this, "Configuration Saved!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MainActivity.this, "Please try again!", Toast.LENGTH_SHORT).show();
                    }
               /* }
                else
                    Toast.makeText(MainActivity.this, "Please connect to a device!", Toast.LENGTH_SHORT).show(); */
            }
        });

        v.findViewById(R.id.btnF1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mBTDevice != null && mBluetoothConnection != null) {
                    String configString = "f1=" + editF1.getText().toString();
                    byte[] bytes = configString.getBytes(Charset.defaultCharset());
                    mBluetoothConnection.write(bytes);

                    Toast.makeText(MainActivity.this, "F1 Sent!", Toast.LENGTH_SHORT).show();
                }
                else
                    Toast.makeText(MainActivity.this, "Please connect to a device!", Toast.LENGTH_SHORT).show();
            }
        });

        v.findViewById(R.id.btnF2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mBTDevice != null && mBluetoothConnection != null) {
                    String configString = "f2=" + editF2.getText().toString();
                    byte[] bytes = configString.getBytes(Charset.defaultCharset());
                    mBluetoothConnection.write(bytes);

                    Toast.makeText(MainActivity.this, "F2 Sent!", Toast.LENGTH_SHORT).show();
                }
                else
                    Toast.makeText(MainActivity.this, "Please connect to a device!", Toast.LENGTH_SHORT).show();
            }
        });

        return new AlertDialog.Builder(this).setView(v);
    }

    // ================= For Map =====================================
    class MyGlobalListenerClass implements ViewTreeObserver.OnGlobalLayoutListener{
        public void onGlobalLayout(){
            pixelGridView=(PixelGridView)findViewById(R.id.pixelGridView);
            pixelGridView.setTotalWidth(pixelGridView.getWidth());
            pixelGridView.setTotalHeight(pixelGridView.getHeight());
            pixelGridView.setNumColumns(15);
            pixelGridView.setNumRows(20);
        }
    }

    // =================== For Directions ============================
    public void turnLeft(View view) {
        if(mBTDevice != null){
            String left = "Pa";
            String turnleft = "Turning left";
            byte[] bytes = left.getBytes(Charset.defaultCharset());
            Log.d(TAG, "mBluetoothConnection " + mBluetoothConnection);
            // Need to check if socket is open
            if(mBluetoothConnection != null){
                mBluetoothConnection.write(bytes);

                commandsSentMessages.append(left + ": " + turnleft.toUpperCase() + "\n");
                tvCommandsSent.setText(commandsSentMessages);
            }
            // mBluetoothConnection.write(bytes);
            tvRobotStatus.setText(turnleft.toUpperCase());

            String position = robot.getPosition();
            String direction = robot.getDirection();
            String grid[] = position.split(",");
            int x = Integer.parseInt(grid[0]);
            int y = Integer.parseInt(grid[1]);
            turnLeftMovement(x,y,direction);
        }
        else{
            Toast.makeText(this, "Please turn on bluetooth", Toast.LENGTH_SHORT).show();
        }
    }

    private void turnLeftMovement(int x, int y, String direction) {
        if(direction == "NORTH"){
            if(y > 0 && y < 19){
                robot.setPosition(x,y);
                robot.setDirection("WEST");
                String updatedposition = y+"|"+x+"|"+"WEST";
                pixelGridView.updateRobotPos(updatedposition);
                pixelGridView.invalidate();
            }
            else{
                Toast.makeText(this, "Invalid Move", Toast.LENGTH_SHORT).show();
            }
        }
        if(direction == "EAST"){
            if(x > 0 && x < 14){
                robot.setPosition(x,y);
                robot.setDirection("NORTH");
                String updatedposition = y+"|"+x+"|"+"NORTH";
                pixelGridView.updateRobotPos(updatedposition);
                pixelGridView.invalidate();
            }
            else{
                Toast.makeText(this, "Invalid Move", Toast.LENGTH_SHORT).show();
            }
        }

        if(direction == "WEST"){
            if(x > 0 && x < 14){
                robot.setPosition(x,y);
                robot.setDirection("SOUTH");
                String updatedposition = y+"|"+x+"|"+"SOUTH";
                pixelGridView.updateRobotPos(updatedposition);
                pixelGridView.invalidate();
            }
            else{
                Toast.makeText(this, "Invalid Move", Toast.LENGTH_SHORT).show();
            }
        }
        if(direction == "SOUTH"){
            if(y > 0 && y < 19){
                robot.setPosition(x,y);
                robot.setDirection("EAST");
                String updatedposition = y+"|"+x+"|"+"EAST";
                pixelGridView.updateRobotPos(updatedposition);
                pixelGridView.invalidate();
            }
            else{
                Toast.makeText(this, "Invalid Move", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void turnRight(View view) {
        if(mBTDevice != null){
            String turnright = "Turning Right";
            String right = "Pd";
            byte[] bytes = right.getBytes(Charset.defaultCharset());
            if(mBluetoothConnection != null){
                mBluetoothConnection.write(bytes);

                commandsSentMessages.append(right + ": " + turnright.toUpperCase() + "\n");
                tvCommandsSent.setText(commandsSentMessages);
            }
            tvRobotStatus.setText(turnright.toUpperCase());

            String position = robot.getPosition();
            String direction = robot.getDirection();
            String grid[] = position.split(",");
            int x = Integer.parseInt(grid[0]);
            int y = Integer.parseInt(grid[1]);
            turnRightMovement(x,y,direction);
        }
        else {
            Toast.makeText(this, "Please turn on bluetooth", Toast.LENGTH_SHORT).show();
        }
    }

    private void turnRightMovement(int x, int y, String direction) {
        if(direction == "NORTH"){
            if(y > 0 && y < 19){
                robot.setPosition(x,y);
                robot.setDirection("EAST");
                String updatedposition = y+"|"+x+"|"+"EAST";
                pixelGridView.updateRobotPos(updatedposition);
                pixelGridView.invalidate();
            }
            else{
                Toast.makeText(this, "Invalid Move", Toast.LENGTH_SHORT).show();
            }
        }
        if(direction == "EAST"){
            if(x > 0 && x < 14){
                robot.setPosition(x,y);
                robot.setDirection("SOUTH");
                String updatedposition = y+"|"+x+"|"+"SOUTH";
                pixelGridView.updateRobotPos(updatedposition);
                pixelGridView.invalidate();
            }
            else{
                Toast.makeText(this, "Invalid Move", Toast.LENGTH_SHORT).show();
            }
        }

        if(direction == "WEST"){
            if(x > 0 && x < 14){
                robot.setPosition(x,y);
                robot.setDirection("NORTH");
                String updatedposition = y+"|"+x+"|"+"NORTH";
                pixelGridView.updateRobotPos(updatedposition);
                pixelGridView.invalidate();
            }
            else{
                Toast.makeText(this, "Invalid Move", Toast.LENGTH_SHORT).show();
            }
        }
        if(direction == "SOUTH"){
            if(y > 0 && y < 19){
                robot.setPosition(x,y);
                robot.setDirection("WEST");
                String updatedposition = y+"|"+x+"|"+"WEST";
                pixelGridView.updateRobotPos(updatedposition);
                pixelGridView.invalidate();
            }
            else{
                Toast.makeText(this, "Invalid Move", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void reverse(View view) {
        if(mBTDevice != null){
            String reverse = "Ps";
            String reverse1 = "Reversing";

            byte[] bytes = reverse.getBytes(Charset.defaultCharset());
            if(mBluetoothConnection != null){
                mBluetoothConnection.write(bytes);

                commandsSentMessages.append(reverse + ": " + reverse1.toUpperCase() + "\n");
                tvCommandsSent.setText(commandsSentMessages);
            }
            tvRobotStatus.setText(reverse1.toUpperCase());

            String position = robot.getPosition();
            String direction = robot.getDirection();
            String grid[] = position.split(",");
            int x = Integer.parseInt(grid[0]);
            int y = Integer.parseInt(grid[1]);
            reverseMovement(x,y,direction);
        }
        else {
            Toast.makeText(this, "Invalid Move", Toast.LENGTH_SHORT).show();
        }
    }

    private void reverseMovement(int x, int y, String direction) {
        if(direction == "NORTH"){
            y = y - 1;
            if(y > 0 && y < 19){
                robot.setPosition(x,y);
                robot.setDirection("NORTH");
                String updatedposition = y+"|"+x+"|"+"NORTH";
                pixelGridView.updateRobotPos(updatedposition);
                pixelGridView.invalidate();
            }
            else{
                Toast.makeText(this, "Invalid Move", Toast.LENGTH_SHORT).show();
            }
        }
        if(direction == "EAST"){
            x = x - 1;
            if(x > 0 && x < 14){
                robot.setPosition(x,y);
                robot.setDirection("EAST");
                String updatedposition = y+"|"+x+"|"+"EAST";
                pixelGridView.updateRobotPos(updatedposition);
                pixelGridView.invalidate();
            }
            else{
                Toast.makeText(this, "Invalid Move", Toast.LENGTH_SHORT).show();
            }
        }

        if(direction == "WEST"){
            x = x + 1;
            if(x > 0 && x < 14){
                robot.setPosition(x,y);
                robot.setDirection("WEST");
                String updatedposition = y+"|"+x+"|"+"WEST";
                pixelGridView.updateRobotPos(updatedposition);
                pixelGridView.invalidate();
            }
            else{
                Toast.makeText(this, "Invalid Move", Toast.LENGTH_SHORT).show();
            }
        }
        if(direction == "SOUTH"){
            y = y + 1;
            if(y > 0 && y < 19){
                robot.setPosition(x,y);
                robot.setDirection("SOUTH");
                String updatedposition = y+"|"+x+"|"+"SOUTH";
                pixelGridView.updateRobotPos(updatedposition);
                pixelGridView.invalidate();
            }
            else{
                Toast.makeText(this, "Invalid Move", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void forward(View view) {
        if(mBTDevice != null){
            String forward = "Pw";
            byte[] bytes = forward.getBytes(Charset.defaultCharset());
            String forward1 = "Moving Forward";
            if(mBluetoothConnection!=null) {
                mBluetoothConnection.write(bytes);

                commandsSentMessages.append(forward + ": " + forward1.toUpperCase() + "\n");
                tvCommandsSent.setText(commandsSentMessages);
            }
            tvRobotStatus.setText(forward1.toUpperCase());

            String position = robot.getPosition();
            String direction = robot.getDirection();
            String grid[] = position.split(",");
            int x = Integer.parseInt(grid[0]);
            int y = Integer.parseInt(grid[1]);
            forwardMovement(x,y,direction);
        }
        else {
            Toast.makeText(this, "Please turn on bluetooth", Toast.LENGTH_SHORT).show();
        }
    }

    private void forwardMovement(int x, int y, String direction) {
        if(direction == "NORTH"){
            y = y + 1;
            if(y > 0 && y < 19){
                robot.setPosition(x,y);
                robot.setDirection("NORTH");
                String updatedposition = y+"|"+x+"|"+"NORTH";
                pixelGridView.updateRobotPos(updatedposition);
                pixelGridView.invalidate();
            }
            else{
                Toast.makeText(this, "Invalid Move", Toast.LENGTH_SHORT).show();
            }
        }
        if(direction == "EAST"){
            x = x + 1;
            if(x > 0 && x < 14){
                robot.setPosition(x,y);
                robot.setDirection("EAST");
                String updatedposition = y+"|"+x+"|"+"EAST";
                pixelGridView.updateRobotPos(updatedposition);
                pixelGridView.invalidate();
            }
            else{
                Toast.makeText(this, "Invalid Move", Toast.LENGTH_SHORT).show();
            }
        }

        if(direction == "WEST"){
            x = x - 1;
            if(x > 0 && x < 14){
                robot.setPosition(x,y);
                robot.setDirection("WEST");
                String updatedposition = y+"|"+x+"|"+"WEST";
                pixelGridView.updateRobotPos(updatedposition);
                pixelGridView.invalidate();
            }
            else{
                Toast.makeText(this, "Invalid Move", Toast.LENGTH_SHORT).show();
            }
        }
        if(direction == "SOUTH"){
            y = y - 1;
            if(y > 0 && y < 19){
                robot.setPosition(x,y);
                robot.setDirection("SOUTH");
                String updatedposition = y+"|"+x+"|"+"SOUTH";
                pixelGridView.updateRobotPos(updatedposition);
                pixelGridView.invalidate();
            }
            else{
                Toast.makeText(this, "Invalid Move", Toast.LENGTH_SHORT).show();
            }
        }
    }


    public static void setCoordinates(int x, int y){
        tvXCoor.setText(String.valueOf(x));
        tvYCoor.setText(String.valueOf(y));
    }

    public void setStartPoint(View view){

        String x_coordinates = tvXCoor.getText().toString();
        String y_coordinates = tvYCoor.getText().toString();
        if(x_coordinates.equals("") || y_coordinates.equals("")){
            tvXCoor.setText("2");
            tvYCoor.setText("2");
            startXY.setText("(" + tvXCoor.getText().toString() + "," + tvYCoor.getText().toString() + ")");
        }

        if(mBTDevice!=null) {
            if (mBTDevice.getBondState() == BluetoothDevice.BOND_BONDED) {
                String startpoint = "SETSTARTPOINT(" + tvXCoor.getText().toString() + "," + tvYCoor.getText().toString() + ")";
                int x = Integer.valueOf(tvXCoor.getText().toString());
                int y = Integer.valueOf(tvYCoor.getText().toString());
                byte[] bytes = startpoint.getBytes(Charset.defaultCharset());
                if(mBluetoothConnection != null ) {
                    mBluetoothConnection.write(bytes);
                }
                commandsSentMessages.append(startpoint + "\n");
                tvCommandsSent.setText(commandsSentMessages);
                startXY.setText("(" + tvXCoor.getText().toString() + "," + tvYCoor.getText().toString() + ")");

                // Original direction is South
                String robotPosition = y + "|" + x + "|" + "NORTH";
                pixelGridView.updateRobotPos(robotPosition);
                pixelGridView.invalidate();
                robot = new Robot(x,y,"NORTH");
                robot.setPosition(x,y);
                robot.setDirection("NORTH");
                pixelGridView.setCellchecked(x,y);
            }
            else{
                Toast.makeText(this, "Please connect to a device", Toast.LENGTH_SHORT).show();
            }
        }
        else{
            Toast.makeText(this, "Please connect to a device", Toast.LENGTH_SHORT).show();
        }
    }

    public void setWayPoint(View view) {
        String x_coordinates = tvXCoor.getText().toString();
        String y_coordinates = tvYCoor.getText().toString();

        if(x_coordinates.equals("") || y_coordinates.equals("")){
            Toast.makeText(this, "Please select valid XY points", Toast.LENGTH_SHORT).show();
        }
        else{
            if(mBTDevice!=null){
                if(mBTDevice.getBondState() == BluetoothDevice.BOND_BONDED){
                    pixelGridView.wpShow();
                    pixelGridView.setWaypoint(Integer.parseInt(tvXCoor.getText().toString()),Integer.parseInt(tvYCoor.getText().toString()));
                    String waypoint = "Pwaypoint(" + tvXCoor.getText() + "," + tvYCoor.getText() + ")"; //"SETWAYPOINT(" + tvXCoor.getText() + "," + tvYCoor.getText() + ")";
                    byte[] bytes = waypoint.getBytes(Charset.defaultCharset());
                    pixelGridView.invalidate();
                    if(mBluetoothConnection != null){
                        mBluetoothConnection.write(bytes);
                    }
                    commandsSentMessages.append(waypoint + "\n");
                    tvCommandsSent.setText(commandsSentMessages);
                    waypointXY.setText("(" + tvXCoor.getText().toString() + "," + tvYCoor.getText().toString() + ")");
                }
                else{
                    Toast.makeText(this, "Please connect to a device", Toast.LENGTH_SHORT).show();
                }
            }
            else{
                Toast.makeText(this, "Please connect to a device", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // ======= Clear map, used for waypoint =============
    public void clear(View view) {
        clearMap();
    }

    private void clearMap(){
        pixelGridView.clearMap();
        pixelGridView.invalidate();
        pixelGridView.wpHide();
        Toast.makeText(this,"Map Cleared",Toast.LENGTH_SHORT).show();
    }

    public void updateMap(View view) {
        Log.d(TAG, "Here update");

        //String update = "sendArena";
        //byte[] bytes = update.getBytes(Charset.defaultCharset());
        if(mBluetoothConnection!=null){
            //mBluetoothConnection.write(bytes);
            messages.append("ARENA INFO" + "\n");
            tvCommandsReceived.setText(messages.toString().toUpperCase());
        }
        else{
            //mBluetoothConnection.write(bytes);
            messages.append("ARENA INFO" + "\n");
            tvCommandsReceived.setText(messages.toString().toUpperCase());
        }
        //listenForUpdate = true;

        if (storedMsg!=null && storedMsg.contains("MDF")) {
            String grid[] = storedMsg.split("\\|");
            //y|x|direction
            String position = grid[1]+"|"+grid[2]+"|"+grid[3];
                robot.setPosition(Integer.parseInt(grid[2]), Integer.parseInt(grid[1]));
                robot.setDirection(grid[3]);
                String exploredMap = grid[4];
                String obstacleMap = grid[5];
                if(exploredMap.matches("^[0-9a-fA-F]+$") && obstacleMap.matches("^[0-9a-fA-F]+$")){
                    tvMDFExploreReceived.setText(exploredMap);
                    tvMDFFastestReceived.setText(obstacleMap);

                    pixelGridView.updateRobotPos(position);
                    pixelGridView.updateArena(exploredMap,obstacleMap);
                    pixelGridView.invalidate();

                    Log.d(TAG, "storedMsg" + storedMsg);
                }
                else{
                    Toast.makeText(MainActivity.this, "Incorrect String format", Toast.LENGTH_SHORT).show();
                }
            //pixelGridView.updateDemoRobotPos(storedMsg);
        }
        //LocalBroadcastManager.getInstance(this).registerReceiver(mReceiver, new IntentFilter("incomingMessage"));
    }

    public void calibrateRobot(View view) {
        if(mBTDevice!= null){
            String calibrate = "Pca";
            byte[] bytes = calibrate.getBytes(Charset.defaultCharset());
            if(mBluetoothConnection != null){
                mBluetoothConnection.write(bytes);
                commandsSentMessages.append(calibrate + ": CALIBRATING" + "\n");
                tvCommandsSent.setText(commandsSentMessages);
            }
            else{
                mBluetoothConnection.write(bytes);
                commandsSentMessages.append(calibrate + ": CALIBRATING" + "\n");
                tvCommandsSent.setText(commandsSentMessages);
            }
        }
    }

    public void startPath(View view) {

        if (startStopBtn.getText().toString().equals("Start")) {

            // Change the text in the Start Button to Stop
            startStopBtn.setText("Stop");

            // Stop changing of switch unless we press stop
            switchPath.setEnabled(false);

            if (tvPath.getText().toString() == "Explore") {

                Log.d(TAG, "Here" + tvPath);

                if (mBTDevice != null) {
                    String explore = "Pbe";
                    byte[] bytes = explore.getBytes(Charset.defaultCharset());
                    if (mBluetoothConnection != null) {
                        mBluetoothConnection.write(bytes);
                    }
                    commandsSentMessages.append(explore + ": BEGIN EXPLORE" + "\n");
                    tvCommandsSent.setText(commandsSentMessages);

                    stillExplore = true;
                    startExploreTime = System.currentTimeMillis();
                    timerHandlerExplore.postDelayed(timerRunnableExplore, 0);
                    disableDirection();
                } else {
                    Toast.makeText(this, "Please connect to a device", Toast.LENGTH_SHORT).show();
                }
            }

            if (tvPath.getText().toString() == "Fastest") {
                // Stop changing of switch unless we press stop
                switchPath.setEnabled(false);

                if (mBTDevice != null) {
                    String fastest = "Pbf";
                    byte[] bytes = fastest.getBytes(Charset.defaultCharset());
                    if (mBluetoothConnection != null) {
                        mBluetoothConnection.write(bytes);
                    }
                    commandsSentMessages.append(fastest + ": BEGIN FASTEST" + "\n");
                    tvCommandsSent.setText(commandsSentMessages);
                    stillFast = true;
                    startFastTime = System.currentTimeMillis();
                    timerHandlerFastest.postDelayed(timerRunnableFastest, 0);
                    disableDirection();
                } else {
                    Toast.makeText(this, "Please connect to a device", Toast.LENGTH_SHORT).show();
                }
            }
        }
        else {
            startStopBtn.setText("Start");
            switchPath.setEnabled(true);

            if(mBTDevice != null){
                String stop = "Pst";
                byte[] bytes = stop.getBytes(Charset.defaultCharset());
                if(mBluetoothConnection!=null){
                    mBluetoothConnection.write(bytes);
                }
                tvRobotStatus.setText("STOPPED");
                commandsSentMessages.append(stop + ": Stop Robot" + "\n");
                tvCommandsSent.setText(commandsSentMessages);

                stillFast = false;
                startFastTime = System.currentTimeMillis();
                timerHandlerFastest.postDelayed(timerRunnableFastest, 0);
                stillExplore = false;
                startExploreTime = System.currentTimeMillis();
                timerHandlerExplore.postDelayed(timerRunnableExplore, 0);
                enableDirection();
            }
            else{
                Toast.makeText(this,"Please connect to a device",Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Handler for exploration timer function
    Handler timerHandlerExplore = new Handler();
    Runnable timerRunnableExplore = new Runnable() {
        @Override
        public void run() {
            if(!stillExplore){
                return;
            }
            long millis = System.currentTimeMillis() - startExploreTime;
            int seconds = (int) (millis / 1000.0);
            int minutes = seconds / 60;
            seconds = seconds % 60;

            explorationreceiveTV.setText(String.format("%d:%d", ((int) minutes), ((int) seconds)));
            timerHandlerExplore.postDelayed(this, 0);
        }
    };


    // Handler for fastest path timer function
    Handler timerHandlerFastest = new Handler();
    Runnable timerRunnableFastest = new Runnable() {
        @Override
        public void run() {
            if(!stillFast){
                return;
            }
            long millis = System.currentTimeMillis() - startFastTime;
            int seconds = (int) (millis / 1000.0);
            int minutes = seconds / 60;
            seconds = seconds % 60;

            fastestreceiveTV.setText(String.format("%d:%d", ((int)minutes), ((int)seconds)));
            timerHandlerFastest.postDelayed(this, 0);
        }
    };

    // ===== Enabling and Disabling Movement when Explore or Fastest Path selected
    private void enableDirection(){
        upBtn.setEnabled(true);
        downBtn.setEnabled(true);
        leftBtn.setEnabled(true);
        rightBtn.setEnabled(true);
        tvMovement.setText("");
        tvMovement.setTextColor(Color.BLACK);
        Toast.makeText(this,"Movement Buttons enabled",Toast.LENGTH_SHORT).show();
    }

    private void disableDirection(){
        upBtn.setEnabled(false);
        downBtn.setEnabled(false);
        leftBtn.setEnabled(false);
        rightBtn.setEnabled(false);
        tvMovement.setText("Movement Disabled");
        tvMovement.setTextColor(Color.RED);
        Toast.makeText(this,"Movement Buttons disabled",Toast.LENGTH_SHORT).show();
    }

    // ======= Resetting when Exploration or Fastest is chosen =========
    public void reset(View view) {
        //startPath(view);
        enableDirection();

        stillExplore=false;
        explorationreceiveTV.setText("0:0");
        stillFast=false;
        fastestreceiveTV.setText("0:0");

        switchPath.setEnabled(true);
        startStopBtn.setEnabled(true);
        startStopBtn.setText("Start");

        clearMap();
    }


    // ============ Sensors ==================
    @Override
    public void onSensorChanged(SensorEvent event) {
        long actualTime = event.timestamp;

        if (tvTilt.getText().toString() == "Off") {
            SM.unregisterListener(MainActivity.this);
        } else {
            // check sensor type
            if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
                if (((actualTime - lastUpdate) > 1000000000)) {
                    // assign directions
                    float x = event.values[0];
                    float y = event.values[1];

                    if (tvTilt.getText().toString() == "On") {

                        if (startup_tilt) {
                            ref_tilt = y;//Capture the 1st y-axis tilt to offset.
                            startup_tilt = false;
                        }

                        if (x < -1) {
                            //When x is negative value, it is tilting towards RIGHT.
                            if (x > -4) {
                                pre_state = 0; //Register position as centered.

                            } else if (x <= -4) {
                                //When x is <= -4, it is expected to turn right.
                                if (pre_state != 2) {
                                    //Tilt right IF previously the state is NOT tilted towards right.
                                    pre_state = 2;

                                    // Turn right
                                    String position = robot.getPosition();
                                    String direction = robot.getDirection();
                                    String grid[] = position.split(",");
                                    int robotx = Integer.parseInt(grid[0]);
                                    int roboty = Integer.parseInt(grid[1]);
                                    turnRightMovement(robotx, roboty, direction);
                                    //Toast.makeText(this, "Turning Right", Toast.LENGTH_SHORT).show();

                                    if (mBTDevice != null) {
                                        String update1 = "turning right";
                                        String update = "Pd";
                                        byte[] bytes = update.getBytes(Charset.defaultCharset());
                                        if (mBluetoothConnection != null) {
                                            mBluetoothConnection.write(bytes);
                                            tvRobotStatus.setText(update1.toUpperCase());

                                            commandsSentMessages.append(update + ": " + update1.toUpperCase() + "\n");
                                            tvCommandsSent.setText(commandsSentMessages);
                                        } else {
                                            mBluetoothConnection.write(bytes);
                                            tvRobotStatus.setText(update1.toUpperCase());

                                            commandsSentMessages.append(update + ": " + update1.toUpperCase() + "\n");
                                            tvCommandsSent.setText(commandsSentMessages);
                                        }
                                    }
                                }
                            }
                        } else if (x > 1) {
                            //When x is a positive value, it is tilting towards LEFT.
                            if (x < 4) {
                                pre_state = 0;
                            } else if (x >= 4) {
                                //When x is >= 4, it is expected to turn left.
                                if (pre_state != 1) {
                                    //Tilt left IF previously the state is NOT tilted towards left.
                                    pre_state = 1;

                                    String position = robot.getPosition();
                                    String direction = robot.getDirection();
                                    String grid[] = position.split(",");
                                    int robotx = Integer.parseInt(grid[0]);
                                    int roboty = Integer.parseInt(grid[1]);
                                    turnLeftMovement(robotx, roboty, direction);
                                    //Toast.makeText(this, "Turning Left", Toast.LENGTH_SHORT).show();

                                    if (mBTDevice != null) {
                                        String update1 = "Pa";
                                        String update = "turning left";
                                        byte[] bytes = update1.getBytes(Charset.defaultCharset());
                                        if (mBluetoothConnection != null) {
                                            mBluetoothConnection.write(bytes);
                                            tvRobotStatus.setText(update.toUpperCase());

                                            commandsSentMessages.append(update1 + ": " + update.toUpperCase() + "\n");
                                            tvCommandsSent.setText(commandsSentMessages);
                                        } else {
                                            mBluetoothConnection.write(bytes);
                                            tvRobotStatus.setText(update.toUpperCase());

                                            commandsSentMessages.append(update1 + ": " + update.toUpperCase() + "\n");
                                            tvCommandsSent.setText(commandsSentMessages);
                                        }
                                    }
                                }
                            }
                        } else if (y < -0.5 + ref_tilt) {
                            //Robots moves at a very slight of tilting forward.
                            String position = robot.getPosition();
                            String direction = robot.getDirection();
                            String grid[] = position.split(",");
                            int robotx = Integer.parseInt(grid[0]);
                            int roboty = Integer.parseInt(grid[1]);
                            forwardMovement(robotx, roboty, direction);

                            //Toast.makeText(this, "Moving Forward", Toast.LENGTH_SHORT).show();

                            if (mBTDevice != null) {
                                String update = "Pw";
                                byte[] bytes = update.getBytes(Charset.defaultCharset());
                                if (mBluetoothConnection != null) {
                                    mBluetoothConnection.write(bytes);
                                    tvRobotStatus.setText("Moving Forward".toUpperCase());

                                    commandsSentMessages.append(update + ": Moving Forward".toUpperCase() + "\n");
                                    tvCommandsSent.setText(commandsSentMessages);
                                } else {
                                    mBluetoothConnection.write(bytes);
                                    tvRobotStatus.setText("Moving Forward".toUpperCase());

                                    commandsSentMessages.append(update + ": Moving Forward".toUpperCase() + "\n");
                                    tvCommandsSent.setText(commandsSentMessages);
                                }
                            }
                        }
                        else if (y > 4.0 + ref_tilt) {
                            String position = robot.getPosition();
                            String direction = robot.getDirection();
                            String grid[] = position.split(",");
                            int robotx = Integer.parseInt(grid[0]);
                            int roboty = Integer.parseInt(grid[1]);
                            reverseMovement(robotx, roboty, direction);

                            //Toast.makeText(this, "Reversing", Toast.LENGTH_SHORT).show();

                            if (mBTDevice != null) {
                                String update = "Ps";
                                byte[] bytes = update.getBytes(Charset.defaultCharset());
                                if (mBluetoothConnection != null) {
                                    mBluetoothConnection.write(bytes);
                                    tvRobotStatus.setText("Reversing".toUpperCase());

                                    commandsSentMessages.append(update + ": Reversing".toUpperCase() + "\n");
                                    tvCommandsSent.setText(commandsSentMessages);
                                } else {
                                    mBluetoothConnection.write(bytes);
                                    tvRobotStatus.setText("Reversing".toUpperCase());

                                    commandsSentMessages.append(update + ": Reversing".toUpperCase() + "\n");
                                    tvCommandsSent.setText(commandsSentMessages);
                                }
                            }
                        }
                    }
                    lastUpdate = actualTime;
                }
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        /* sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL);*/
        mLastAccelerometerSet = false;
        mLastMagnetometerSet = false;
        mSensorManager.registerListener(MainActivity.this, mAccelerometer,
                SensorManager.SENSOR_DELAY_FASTEST);
        mSensorManager.registerListener(MainActivity.this, mMagnetometer,
                SensorManager.SENSOR_DELAY_FASTEST);
    }

    @Override
    public void onAccuracyChanged(Sensor arg0, int arg1) {
    }


} //end

