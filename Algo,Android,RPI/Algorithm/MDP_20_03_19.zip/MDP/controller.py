import re
from tkinter.filedialog import askopenfilename
import threading
from ast import literal_eval
from time import time, sleep

from exploration import Exploration
from fastest_path import *
from connection_client import Sender


class Controller:
    def __init__(self):
        print('real run')
        self._last_calibrate = 0
        self._explore_limit = 100.0
        self._time_limit = 720
        from robot import Robot
        self._robot = Robot(exploration_status=[[0] * 15 for _ in range(20)],
                            facing=NORTH,
                            discovered_map=[[2] * 15 for _ in range(20)])
        self._sender = Sender(self._msg_handler)
        self._auto_update = True
        enable_print()
        print('init complete!')
        disable_print()
        try:
            import winsound
            frequency = 2500
            duration = 250
            winsound.Beep(frequency, duration)
            winsound.Beep(frequency, duration)
        except ImportError:
            enable_print()
            print('beep')
            disable_print()

    def _msg_handler(self, msg):
        if msg == "ca":
            thread = threading.Thread(target=self._calibrate)
            thread.daemon = True
            thread.start()
        elif msg == "be":
            thread = threading.Thread(target=self._explore)
            thread.daemon = True
            thread.start()
        elif msg[0:8] == "waypoint":
            enable_print()
            print('before set')
            self._set_way_point(msg[8:])
            print('after set')
            disable_print()
        elif msg == "bf":
            thread = threading.Thread(target=self._move_fastest_path)
            thread.daemon = True
            thread.start()
        elif msg == "st":
            pass
        elif msg == "w":
            self._sender.send_arduino('w')
            self._sender.wait_arduino('D')
        elif msg == "a":
            self._sender.send_arduino('a')
            self._sender.wait_arduino('D')
        elif msg == "d":
            self._sender.send_arduino('d')
            self._sender.wait_arduino('D')
        elif msg == "s":
            self._sender.send_arduino('s')
            self._sender.wait_arduino('D')

    def _set_way_point(self, coordinate):
        (col, row) = literal_eval(coordinate)
        self._way_point = (row, col)

    def _calibrate(self):
        self._sender.send_arduino('f')
        self._sender.wait_arduino('D')

    def _update_android(self, override=True):
        if self._auto_update or override:
            y, x = get_coordinates(self._robot.center)
            direction = get_direction_str(self._robot.facing)
            mdf = 'MDF|%s|%s|%s|%s|%s' % (str(y), str(x), direction, self._robot.get_explore_string(),
                                          self._robot.get_map_string())
            print('(%d,%d)' % (y, x))
            self._sender.send_android(mdf)

    def _explore(self):
        start_time = time()
        exploration = Exploration(self._robot, start_time, self._explore_limit, self._time_limit)

        run = exploration.start_real(self._sender)

        next(run)
        self._update_android()
        while True:
            try:
                # Exploration until completion

                while True:
                    run.send(0)

                    self._robot.auto_calibrate(self._sender)
                    self._update_android()

                    run.send(0)

                    self._update_android()
                    self._robot.last_calibrate += 1

                    is_complete = run.send(0)
                    if is_complete:
                        break

                    is_looped = run.send(0)
                    if is_looped:
                        while True:
                            self._robot.last_calibrate += 1
                            updated_or_moved, value, is_complete = run.send(0)
                            self._robot.auto_calibrate(self._sender)
                            if updated_or_moved == "updated" or updated_or_moved == "moved":
                                self._update_android()

                            else:
                                break

                            if is_complete:
                                break
                        break

                # Returning to start after completion
                while True:
                    run.send(0)
                    self._update_android()

            except StopIteration:
                enable_print()
                print('EXPLORE_STR:', self._robot.get_explore_string())
                print('MAP_STR:', self._robot.get_map_string())
                disable_print()
                print('Returned to start!')
                if self._robot.facing == WEST:
                    print('ENTERED FACING WEST')
                    self._robot.turn_robot(self._sender, RIGHT)
                    self._calibrate()
                elif self._robot.facing == SOUTH:
                    print('ENTERED FACING SOUTH')
                    self._robot.turn_robot(self._sender, BACKWARD)
                    self._calibrate()
                break

        print('Calibrating...')
        self._calibrate_after_exploration()

    def _calibrate_after_exploration(self):
        self._fastest_path = self._find_fastest_path()
        self._update_android()
        self._sender.send_android('endExplore')

    def _find_fastest_path(self):
        from simulator import Robot
        clone_robot = Robot(exploration_status=self._robot.exploration_status,
                            facing=self._robot.facing,
                            discovered_map=self._robot.discovered_map,
                            real_map=[[0] * 15 for _ in range(20)])

        fastest_path_start_way_point = get_shortest_path_moves(clone_robot,
                                                               start=(1, 1),
                                                               goal=self._way_point)

        if fastest_path_start_way_point:
            for move in fastest_path_start_way_point:
                clone_robot.move_robot(move)

        before_way_point = previous_cell(clone_robot.center, clone_robot.facing)

        fastest_path_way_point_goal = get_shortest_path_moves(clone_robot,
                                                              start=self._way_point,
                                                              goal=(18, 13),
                                                              before_start_point=before_way_point)

        return fastest_path_start_way_point + fastest_path_way_point_goal

    def _move_fastest_path(self):
        if self._fastest_path:
            move_str = get_fastest_path_move_string(self._fastest_path)
            enable_print()
            print("Fastest Path: %s" % move_str)
            disable_print()
            moves = move_str.split('/')
            for move in moves:
                move_len = len(move)
                if move_len == 1:
                    self._sender.send_arduino(move)
                    self._sender.wait_arduino('D')
                else:
                    #move_multi = "%dw" % move_len
                    for m in move:
                    #self._sender.send_arduino(move_multi)
                        self._sender.send_arduino(m)
                        self._sender.wait_arduino('D')
            self._sender.send_android('endFastest')
        else:
            print("No valid path")
