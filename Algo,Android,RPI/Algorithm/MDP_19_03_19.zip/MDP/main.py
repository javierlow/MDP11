from tkinter import *
import GUI

if __name__ == '__main__':
    win = Tk()
    gui = GUI.Window(win)
    win.resizable(False, False)
    win.mainloop()
