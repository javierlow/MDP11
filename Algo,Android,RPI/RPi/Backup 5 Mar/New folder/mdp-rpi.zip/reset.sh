sudo rfcomm release 4
sudo hciconfig hci0 piscan